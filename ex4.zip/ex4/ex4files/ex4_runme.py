"""
===================================================
     Introduction to Machine Learning (67577)
===================================================

Running script for Ex4.

Author:
Date: May, 2018

"""

import numpy as np
import adaboost
import ex4_tools

def Q3(): # AdaBoost
    # TODO - implement this function
    [X_train, y_train] = [np.loadtxt("SynData\X_train.txt"), np.loadtxt("SynData\y_train.txt")]
    for i in range(1,21):
        ada = adaboost.AdaBoost(ex4_tools.DecisionStump,i*5)
        ada.train(X_train, y_train)
        h_hat = ada.error(X_train, y_train)
    print(h_hat)



    return

Q3()

def Q4(): # decision trees
    # TODO - implement this function
    return

def Q5(): # spam data
    # TODO - implement this function
    return

if __name__ == '__main__':
    # TODO - run your code for questions 3-5
    pass
