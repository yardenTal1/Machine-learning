"""
===================================================
     Introduction to Machine Learning (67577)
===================================================

Skeleton for the AdaBoost classifier.

Author: Noga Zaslavsky
Edited: Yoav Wald, May 2018

"""
import numpy as np

class AdaBoost(object):

    def __init__(self, WL, T):
        """
        Parameters
        ----------
        WL : the class of the base weak learner
        T : the number of base learners to learn
        """
        self.WL = WL
        self.T = T
        self.h = [None]*T     # list of base learners
        self.w = np.zeros(T)  # weights

    def train(self, X, y):
        """
        Train this classifier over the sample (X,y)
        """
        m = len(y)
        # D = [1/m] * m
        D = np.full(m, 1/m)
        for t in range(self.T):
            error_t = 0
            normalization = 0
            self.h[t] = self.WL(D, X, y)
            self.h[t].train(D,X,y)
            for i in range(m):
                if y[i] != self.h[t].predict(X)[i]:
                    error_t += D[i]
            self.w[t] = 1/2 * np.log(1/error_t - 1)
            for j in range(m):
                normalization += D[j] * np.exp(-self.w[t] * self.h[t].predict(X)[j])
            for i in range(m):
                D[i] = D[i] * np.exp(-self.w[t] * y[i] * self.h[t].predict(X)[i])/normalization


    def predict(self, X):
        """
        Returns
        -------
        y_hat : a prediction vector for X
        """
        h_hat = np.zeros(len(X))
        for t in range(self.T):
            h_hat += self.h[t].predict(X) * self.w[t]
        return np.sign(h_hat)


    def error(self, X, y):
        """
        Returns
        -------
        the error of this classifier over the sample (X,y)
        """
        m = len(y)
        num_of_error = 0
        self.train(X,y)
        h_hat = self.predict(X)
        for i in range(m):
            if y[i] != h_hat[i]:
                num_of_error +=1
        error_percent = num_of_error / m
        return error_percent



