import numpy as np

class perceptron:

    def __init__(self):
        self.weights = np.zeros(1)

    def fit(self, x, y):
        m = len(x[1]) # m is the number of features
        n = len(y) # n is the number of sampels
        self.weights =np.zeros(m)
        x_np = np.asarray(x)
        y_np = np.asarray(y)
        flag = False

        while(not flag):
            flag = True
            y_prediction = np.dot(x_np, self.weights)
            for i in range(n):
                if np.dot(y_prediction[i],y_np[i]) <= 0:
                    self.weights = np.add(self.weights, np.dot(y_np[i],x_np[i]))
                    flag = False
                    break

    def predict(self, x):
        return np.sign(np.dot(x,self.weights))

    def score(self, x, y):
        perseptron_accuracy = 0
        n = len(y)  # n is the number of sampels
        y_np = np.asarray(y)
        for i in range(n):
            if int(self.predict(x[i])) == int(y_np[i]):
                perseptron_accuracy += 1
        mean_perseptron_accuracy = perseptron_accuracy / n
        return mean_perseptron_accuracy












