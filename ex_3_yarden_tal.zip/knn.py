import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics.pairwise import euclidean_distances


data = plt.np.loadtxt('spam.data')
NP = 0
NN = 0
TEST_SIZE = 1000

K = [1, 2, 5, 10, 100]

tpr_arr =[]
fpr_arr =[]
ni_arr =[]

x_data = data[:, :-1]
y_data = data[:, -1]
CURRENTLY_SIZE = TEST_SIZE/ data.shape[0]
train_x, test_x, train_y, test_y = train_test_split(x_data, y_data, test_size= CURRENTLY_SIZE)
tast_num = len(test_x)

logistic_model = LogisticRegression()
logistic_model.fit(train_x, train_y)

logistic_model_proba = logistic_model.predict_proba(test_x)[:,1]
sorted_proba_index = plt.np.argsort(logistic_model_proba).tolist()[::-1]

for i in range(len(test_y)):
    if test_y[i] == 1:
        NP +=1
    else:
        NN +=1

ni_arr.append(0)
for i in range(NP):
    count = 0
    threshold = 0
    for j in sorted_proba_index:
        if test_y[j] == 1:
            count += 1
        threshold += 1
        if count == i:
            ni_arr.append(threshold)
            break
    tpr_arr.append(i/NP)

for i in range(NP):
    fpr_arr.append((ni_arr[i] - i) /NN)
tpr_arr.append(1)
fpr_arr.append(1)

plt.clf()
plt.plot(fpr_arr,tpr_arr, label="tpr to fpr")
plt.xlabel("FALSE POSITIVE RATE")
plt.ylabel("TRUE POSITIVE RATE")
plt.legend()
plt.title("empirical roc curve")
# plt.show()
plt.savefig("tpr_to_fpr")


class knn:

    def __init__(self, k):
        self.knn = k


    def fit(self, x,y):
        self.x = x
        self.y = y

    def predict(self,x):
        distance = euclidean_distances([x],self.x)[0]
        sorted_first_k_index = plt.np.argsort(distance)[:self.knn]
        count_y_false = 0
        count_y_true = 0

        for i in sorted_first_k_index:
            if self.y[i] == 0:
                count_y_false +=1
            else:
                count_y_true +=1

        return count_y_true > count_y_false

test_errors =[]

for k in K:
    count_errors = 0
    my_knn = knn(k)
    my_knn.fit(train_x, train_y)
    y_knn = np.apply_along_axis(my_knn.predict, 1, test_x)
    for y in range(len(y_knn)):
        if y_knn[y] != test_y[y]:
            count_errors += 1
    test_errors.append(count_errors / TEST_SIZE)

plt.clf()
plt.plot(K, test_errors, label="test errors as a function of k")
plt.xlabel("K")
plt.ylabel("TEST ERRORS")
plt.legend()
plt.title("test errors as a function of k")
# plt.show()
plt.savefig("test_errors")
















