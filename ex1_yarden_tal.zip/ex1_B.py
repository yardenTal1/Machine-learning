import pandas as pd
import numpy as np
from numpy import dot
from numpy.linalg import pinv
import matplotlib.pyplot as plt

COLS = ["bedrooms", "bathrooms", "sqft_living", "sqft_lot", "floors",
        "condition", "grade", "sqft_above", "sqft_basement", "sqft_living15",
        "sqft_lot15", "lat", "long"]

def training (df):
    error_training_data = []
    error_test_data = []

    for x in range(1,100):
        training_data = df.sample(frac=float(x) / 100)
        test_data = df.drop(training_data.index)
        # split y from the data
        y_training = training_data["price"].as_matrix()
        training_data = training_data.drop(['price'], axis=1).as_matrix()
        # calculate w hat and y hat
        w_hat = dot(pinv(training_data), y_training)
        y_hat = dot(training_data, w_hat)
        # add the norm value to the error training data
        error_training_data.append((((y_training - y_hat) ** 2).mean()) ** 0.5)

        # calculate the y test
        y_test = test_data["price"].as_matrix()
        test_data = test_data.drop(['price'], axis=1).as_matrix()
        # calculate the y hat with the w hat that is calculated in the training
        y_hat = dot(test_data, w_hat)
        # add the norm value to the error test data
        error_test_data.append((((y_test - y_hat) ** 2).mean()) ** 0.5)


    plt.plot(error_test_data, label = "test")
    plt.plot(error_training_data, label = "training")
    plt.legend()
    plt.savefig("test_error_training_error1")



df = pd.read_csv("kc_house_data.csv")

# pre processing  - remove and handle with corrupted data

# remove data with null value
df.dropna(how = "any", inplace= True)

# remove data with invalid values
df = df.drop(df[df.price <= 0].index)
df = df.drop(df[df.bedrooms < 1].index)
df = df.drop(df[df.sqft_living <= 0].index)
df = df.drop(df[df.bathrooms < 1].index)
df = df.drop(df[df.sqft_living15 <= 0].index)
df = df.drop(df[df.sqft_lot15 <= 0].index)
df = df.drop(df[df.floors <= 0].index)
df = df.drop(df[df.sqft_above <= 0].index)
df = df.drop(df[df.sqft_basement < 0].index)
df = df.drop(df[df.zipcode <= 0].index)
df = df.drop(df[df.yr_built <= 0].index)
df = df.drop(df[(df.waterfront != 0) & (df.waterfront != 1)].index)
df = df.drop(df[df.condition < 0].index)
df = df.drop(df[df.grade < 0].index)

# Delete columns that are not relevant to setting a price
df = df.drop(['id', 'date', 'view'], axis=1)

# Categorical Feature
df = pd.get_dummies(df, columns=['zipcode'])
# Add a feature with a value of 1 for the Linear Regression process
df["b"] = 1
# Make sure that the home improvement year is greater than or equal to the
#  year of construction
df["yr_renovated"] = df[["yr_renovated", "yr_built"]].max(axis=1)

# values that are far from the average
for col in COLS:
    mean = df[col].mean()
    std = df[col].std()
    df = df.loc[np.abs(df[col] - mean) <= 3 * std]

df.to_csv(r"new_data.csv")

training(df)





