import numpy as np
import matplotlib.pyplot as plt

data = np.random.binomial(1, 0.25, (100000,1000))
SECUENCES = 5
ROWS = 100000
TOSSES = 1000
EPSILONS = [0.5, 0.25, 0.1, 0.01, 0.001]
P = 0.25

# For the first 5 sequences of 1000 tosses (the first 5 rows in data),
#  calculate the mean of all tosses up to m

for i in range(SECUENCES):
    sum_of_tosses = 0
    estimated_array = []

    for j in range(TOSSES):
        sum_of_tosses += data[i,j]
        estimated = float(sum_of_tosses)/(j+1)
        estimated_array.append(estimated)
    plt.plot(estimated_array, label="toss " + str(i + 1), linewidth=0.75)

plt.legend()
plt.title('estimates of the first 5 sequences')
plt.xlabel('number of tosses')
plt.ylabel('p estimation for m tosses')
plt.savefig('estimates of the first 5 sequences')
plt.clf()


for e in range(len(EPSILONS)):
    chebyshev = []
    hoeffding = []
    percent_m = []
    sum_of_tosses = [0]*ROWS
    for m in range(TOSSES):

        # upper bound for Chebyshev and Hoeffding
        upper_bound_ch = float(1)/(4*(m+1)*(EPSILONS[e]**2))
        upper_bound_ho = 2 * np.exp(-2*(m+1)*EPSILONS[e]**2)
        # bounding a probability so a bound greater then 1 is irrelevant
        chebyshev.append(min(upper_bound_ch,1))
        hoeffding.append(min(upper_bound_ho,1))

        sum1 = 0

        for r in range(ROWS):
            # for each m (column) we check the percentage of sequences that
            #  satisfy: (estimated - P) >= EPSILONS[e]:
            sum_of_tosses[r] += data[r, m]
            estimated = float(sum_of_tosses[r]) / (m + 1)
            if abs(estimated - P) >= EPSILONS[e]:
                sum1 += 1
        percent = (float(sum1) / ROWS)
        percent_m.append(percent)

    plt.plot(chebyshev, label = "chebyshev")
    plt.title(str("The epsilon is ")+str(EPSILONS[e]))
    plt.plot(hoeffding, label = "hoeffding")
    plt.plot(percent_m, label = "satisfying_percentage")
    plt.legend()
    plt.savefig("fig" + str(e))
    plt.clf()



















