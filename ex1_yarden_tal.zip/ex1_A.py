from numpy import diag, zeros
from numpy.linalg import svd, norm, matrix_rank
from matplotlib.pyplot import*
import scipy.misc as misc
import matplotlib.pyplot as plt


image = misc.ascent()
U, s, V = svd(image)
frobenius = []
compression_ratio = []
r = matrix_rank(diag(s))
MATRIX_SIZE = 512

for k in range(512):
    # Creates a diagonal matrix with K singular values , where -1<k<513
    singular_vec = np.zeros(512)
    singular_vec[:k] = s[:k]
    sig = diag(singular_vec)
    new_matrix = np.dot(np.dot(U, sig), V)
    # For each k calculate the Frobenius distance between the original
    #  and the reconstructed images
    frobenius.append(np.linalg.norm(image-new_matrix))
    # For each k calculate the compression ratio
    compression_ratio.append(float(2*k*MATRIX_SIZE+k)/(2*MATRIX_SIZE*r+r))

    # Plot 5 distinguishable reconstructed images for 5 different
    # values of 0 <= k <= 512.
    if k == 1 or k == 20 or k == 100 or k == 300 or k == 500:
        imshow(new_matrix)
        ylabel("k: " +str(k)+"\nForbenius: " +str(frobenius[k]) +"\nratio "+str(compression_ratio[k]))
        savefig("approximate_image_num_"+str(k))
        show()

plt.plot(frobenius)
plt.savefig("frobenius")
plt.show()
plt.plot(compression_ratio)
plt.savefig("ratio")
plt.show()












